sap.ui.define(["sap/m/MessageToast"],function(e){"use strict";return{onPress:function(s){debugger;e.show(" Payment Bill Is Sent")}}});
//# sourceMappingURL=PaymentDetails.js.map